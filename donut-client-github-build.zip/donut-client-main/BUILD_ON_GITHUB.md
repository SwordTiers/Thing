# Build Donut Client into a JAR (no local Gradle setup)

This project includes a GitHub Actions workflow that builds a Fabric Minecraft 1.21.11 client-side mod using Java 21. The artifact is `donut-client-1.1.0.jar`.

## Steps

1. Create a new repository at https://github.com/new (private is fine).
2. Extract the ZIP archive and **upload its contents**, preserving the `.github/workflows/build-jar.yml` file and all other project folders. Do not upload only the ZIP. Commit the files to the repository's `main` branch.
3. In the repository, open **Actions** > **Build Donut Client JAR**. The workflow is automatically triggered by a push to `main` or `master`; you can also use **Run workflow**.
4. Open the completed workflow run. Under **Artifacts**, download `donut-client-1.1.0`.
5. Extract that artifact ZIP. Copy `donut-client-1.1.0.jar` into your Minecraft mods folder with Fabric Loader and Fabric API installed for Minecraft 1.21.11.

The workflow runs `./gradlew --no-daemon remapJar --stacktrace` to produce the installable JAR, without running optional tests that are not necessary for packaging the mod.

## Local build

Use JDK 21 and an internet connection that allows access to `services.gradle.org`, `maven.fabricmc.net`, `repo.maven.apache.org` and Minecraft downloads.

Windows: `gradlew.bat remapJar --stacktrace`

macOS/Linux: `./gradlew remapJar --stacktrace`

If the build fails even in GitHub Actions, inspect the **Build installable mod JAR** log. The source code itself has not been compiled or verified in this environment because network access to the Gradle distribution/dependencies is unavailable.
